TO COMPILE
javac @sources.txt

TO RUN
Ensure the folder "Assignment" has been added to the classpath
java Hark

TO VIEW DOCUMENTATION
firefox Assignment/overview-summary.html

Some handy-dandy Ability and Character csv files have been provided:
TestAbilities.txt
TestCharacters.txt

Additionally, a game already in progress has been saved for you:
TestSave

Have fun!
